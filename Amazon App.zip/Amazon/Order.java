public class Order {
    public String odid;
    public String prid;
    public String buyid;
    public String selid;
    public int pri;
    public int dis;
    public String status;

    Order(String a,String b,String c,String d,int e,int f,String g)
    {
        odid=a;
        prid=b;
        buyid=c;
        selid=d;
        pri=e;
        dis=f;
        status=g;
    }

    public String toString()
    {
        return ;
    }
}
